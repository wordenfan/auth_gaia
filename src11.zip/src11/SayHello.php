<?php

namespace Labsys\GaiaAuth;

class SayHello
{
    public static function world()
    {
        return 'Hello World!';
    }
}
