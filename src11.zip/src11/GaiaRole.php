<?php
/**
 * Created by PhpStorm.
 * User: benchao
 * Date: 16/11/22
 */

namespace Labsys\GaiaAuth;


class GaiaRole
{
    protected $config;

    public function __construct()
    {

    }

    public function packageTest($str)
    {
        echo $str;
    }
}
