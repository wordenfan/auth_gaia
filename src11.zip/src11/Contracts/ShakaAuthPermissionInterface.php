<?php
namespace Labsys\GaiaAuth\Contracts;

/**
 * This file is part of Entrust,
 * a role & permission management solution for Laravel.
 *
 * @license MIT
 * @package Zizaco\Entrust
 */

interface ShakaAuthPermissionInterface
{

}
